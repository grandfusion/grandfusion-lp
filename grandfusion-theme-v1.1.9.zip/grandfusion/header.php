<?php
/**
 * Header template for the GrandFusion theme.
 *
 * @package GrandFusion
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="profile" href="https://gmpg.org/xfn/11">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;500;600&family=Noto+Sans+JP:wght@300;400;500;700&family=Noto+Serif+JP:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'メインコンテンツへスキップ', 'grandfusion' ); ?></a>

<header class="header" role="banner">
  <div class="header-inner">
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="logo" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
      <?php
      if ( has_custom_logo() ) {
        the_custom_logo();
      } else {
        ?>
        GrandFusion
        <small><?php echo esc_html( get_bloginfo( 'description' ) ); ?></small>
        <?php
      }
      ?>
    </a>

    <button class="menu-btn" id="menuBtn" aria-label="<?php esc_attr_e( 'メニューを開く', 'grandfusion' ); ?>" aria-expanded="false" aria-controls="primary-nav">
      <span class="menu-btn-bar"></span>
      <span class="menu-btn-bar"></span>
      <span class="menu-btn-bar"></span>
    </button>

    <nav class="nav" id="primary-nav" role="navigation" aria-label="<?php esc_attr_e( 'メインナビゲーション', 'grandfusion' ); ?>">
      <?php
      if ( has_nav_menu( 'primary' ) ) {
        wp_nav_menu( array(
          'theme_location' => 'primary',
          'container'      => false,
          'menu_class'     => 'nav-list',
          'items_wrap'     => '%3$s',
          'depth'          => 2,
          'fallback_cb'    => false,
        ) );
      } else {
        ?>
        <ul class="nav-list">
          <li class="menu-item menu-item-has-children">
            <a href="<?php echo esc_url( home_url( '/beauty_salon_mgmt/' ) ); ?>">エステサロン経営</a>
            <ul class="sub-menu">
              <li><a href="https://salon-mgmt.grandfusion-official.site/" target="_blank" rel="noopener"><strong>SALON SUPPORT</strong><small>salon management</small></a></li>
              <li><a href="https://kaigyo.grandfusion-official.site/" target="_blank" rel="noopener">サロン開業サポート<small>start up support</small></a></li>
              <li><a href="https://financing.grandfusion-official.site/" target="_blank" rel="noopener">融資サポート<small>financing support</small></a></li>
            </ul>
          </li>
          <li class="menu-item menu-item-has-children">
            <a href="<?php echo esc_url( home_url( '/machine_sales/' ) ); ?>">マシン販売</a>
            <ul class="sub-menu">
              <li><a href="https://lp.grandfusion-official.site/" target="_blank" rel="noopener"><strong>CLINICAL MACHINES</strong><small>all products</small></a></li>
              <li><a href="https://btxtherma.grandfusion-official.site/" target="_blank" rel="noopener">BTXtherma<small>clinical grade RF</small></a></li>
              <li><a href="https://regecell.grandfusion-official.site/" target="_blank" rel="noopener">リジェセル<small>electroporation</small></a></li>
            </ul>
          </li>
          <li class="menu-item menu-item-has-children">
            <a href="https://lp.grandfusion-official.site/" target="_blank" rel="noopener">ヌドゥーク</a>
            <ul class="sub-menu">
              <li><a href="https://lp.grandfusion-official.site/" target="_blank" rel="noopener"><strong>NUDUQUE トップページ</strong><small>brand top</small></a></li>
              <li><a href="<?php echo esc_url( home_url( '/nuduke/' ) ); ?>"><strong>ブログ</strong><small>NUDUQUE blog</small></a></li>
            </ul>
          </li>
          <li class="menu-item"><a href="https://hair-salon.grandfusion-official.site/" target="_blank" rel="noopener">美容室</a></li>
          <li class="menu-item"><a href="<?php echo esc_url( home_url( '/events/' ) ); ?>">イベント・セミナー</a></li>
          <li class="menu-item"><a href="<?php echo esc_url( home_url( '/blog/' ) ); ?>">BLOG</a></li>
          <li class="menu-item"><a href="https://liff.line.me/2004208943-gqypDjX5?unique_key=Tc2pkO&amp;ts=1784529110" target="_blank" rel="noopener" class="cta-btn">お問い合わせ</a></li>
        </ul>
        <?php
      }
      ?>
    </nav>
  </div>
</header>

<main id="content" class="site-main" role="main">
