<?php
/**
 * 投稿アーカイブテンプレート（archive.php）
 *
 * カテゴリー一覧、タグ一覧、年月別アーカイブ、ブログ一覧などに使用されます。
 *
 * @package GrandFusion
 */
get_header();
?>

<section class="page-hero">
  <div class="page-hero-inner">
    <nav class="breadcrumb" aria-label="<?php esc_attr_e( 'パンくず', 'grandfusion' ); ?>">
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>">TOP</a>
      <span class="breadcrumb-sep">/</span>
      <span class="breadcrumb-current"><?php
        if ( is_home() ) {
          esc_html_e( 'ブログ', 'grandfusion' );
        } else {
          the_archive_title();
        }
      ?></span>
    </nav>

    <div class="page-en"><?php
      if ( is_home() ) {
        echo 'Blog';
      } elseif ( is_post_type_archive() ) {
        echo 'Business';
      } elseif ( is_category() ) {
        echo 'Category';
      } elseif ( is_tag() ) {
        echo 'Tag';
      } else {
        echo 'Archive';
      }
    ?></div>
    <h1 class="page-title"><?php
      if ( is_home() ) {
        esc_html_e( 'ブログ・お役立ち情報', 'grandfusion' );
      } else {
        the_archive_title();
      }
    ?></h1>
    <?php if ( is_category() || is_tag() || is_author() ) : ?>
      <div class="archive-desc"><?php the_archive_description(); ?></div>
    <?php endif; ?>
  </div>
</section>

<section class="archive-body section">
  <div class="section-inner">
    <?php if ( have_posts() ) : ?>

      <div class="archive-grid">
        <?php while ( have_posts() ) : the_post(); ?>
          <a href="<?php the_permalink(); ?>" class="archive-card" id="post-<?php the_ID(); ?>">
            <div class="archive-card-img">
              <?php
              if ( has_post_thumbnail() ) {
                the_post_thumbnail( 'medium_large', array( 'loading' => 'lazy' ) );
              } else {
                echo '<span class="archive-card-no-img">GrandFusion</span>';
              }
              ?>
            </div>
            <div class="archive-card-body">
              <div class="archive-card-meta">
                <span class="archive-card-date"><?php echo esc_html( get_the_date( 'Y.m.d' ) ); ?></span>
                <?php
                $categories = get_the_category();
                if ( ! empty( $categories ) ) {
                  echo '<span class="archive-card-cat">' . esc_html( $categories[0]->name ) . '</span>';
                }
                ?>
              </div>
              <h2 class="archive-card-title"><?php the_title(); ?></h2>
              <p class="archive-card-excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 50, '…' ) ); ?></p>
              <span class="archive-card-more">READ MORE →</span>
            </div>
          </a>
        <?php endwhile; ?>
      </div>

      <div class="archive-pagination">
        <?php
        the_posts_pagination( array(
          'prev_text' => '← ' . esc_html__( '前へ', 'grandfusion' ),
          'next_text' => esc_html__( '次へ', 'grandfusion' ) . ' →',
          'mid_size'  => 2,
        ) );
        ?>
      </div>

    <?php else : ?>
      <div class="archive-empty">
        <p>該当する記事が見つかりませんでした。</p>
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn">トップへ戻る</a>
      </div>
    <?php endif; ?>
  </div>
</section>

<?php
get_footer();
