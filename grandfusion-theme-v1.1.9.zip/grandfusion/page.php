<?php
/**
 * 固定ページ汎用テンプレート（page.php）
 *
 * about / contact / faq / academy / nuduque など、
 * 個別テンプレートがない固定ページはすべてこのテンプレートで表示されます。
 *
 * @package GrandFusion
 */
get_header();
?>

<section class="page-hero">
  <div class="page-hero-inner">
    <?php
    $ancestors = get_post_ancestors( get_the_ID() );
    if ( ! is_front_page() ) :
    ?>
    <nav class="breadcrumb" aria-label="<?php esc_attr_e( 'パンくず', 'grandfusion' ); ?>">
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>">TOP</a>
      <span class="breadcrumb-sep">/</span>
      <?php
      $ancestors = array_reverse( $ancestors );
      foreach ( $ancestors as $ancestor_id ) {
        printf(
          '<a href="%s">%s</a><span class="breadcrumb-sep">/</span>',
          esc_url( get_permalink( $ancestor_id ) ),
          esc_html( get_the_title( $ancestor_id ) )
        );
      }
      ?>
      <span class="breadcrumb-current"><?php the_title(); ?></span>
    </nav>
    <?php endif; ?>

    <?php
    $slug = get_post_field( 'post_name', get_the_ID() );
    $en_label = strtoupper( $slug );
    ?>
    <div class="page-en"><?php echo esc_html( $en_label ); ?></div>
    <h1 class="page-title"><?php the_title(); ?></h1>
  </div>
</section>

<?php while ( have_posts() ) : the_post(); ?>

<section class="page-body section">
  <article id="post-<?php the_ID(); ?>" <?php post_class( 'page-article' ); ?>>
    <?php if ( has_post_thumbnail() ) : ?>
      <div class="page-thumb">
        <?php the_post_thumbnail( 'large', array( 'loading' => 'lazy' ) ); ?>
      </div>
    <?php endif; ?>

    <div class="entry-content">
      <?php
      the_content();

      wp_link_pages( array(
        'before' => '<div class="page-links">' . esc_html__( 'ページ:', 'grandfusion' ),
        'after'  => '</div>',
      ) );
      ?>
    </div>
  </article>
</section>

<?php endwhile; ?>

<!-- 関連リンクの誘導（共通フッターCTA） -->
<section class="page-foot-cta">
  <div class="page-foot-cta-inner">
    <div class="page-foot-cta-en">Contact</div>
    <h2 class="page-foot-cta-title">お問い合わせ・ご相談</h2>
    <p class="page-foot-cta-text">
      製品導入・サロン開業のご相談など、お気軽にお問い合わせください。
    </p>
    <div class="page-foot-cta-buttons">
      <a href="https://liff.line.me/2004208943-gqypDjX5?unique_key=Tc2pkO&amp;ts=1784529110" target="_blank" rel="noopener" class="btn btn-fill">お問い合わせフォーム</a>
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn">トップへ戻る</a>
    </div>
  </div>
</section>

<?php
get_footer();
