<?php
/**
 * Front Page template for the GrandFusion theme.
 *
 * 表示順：
 *   Hero → Vision → Philosophy → Lineup CTA → Support → Difference → Voice → Mission → Contact
 *
 * @package GrandFusion
 */
get_header();

$theme_uri = get_template_directory_uri();
?>

<!-- ===== HERO ===== -->
<section class="fp-hero">
  <div class="fp-hero-inner">
    <div class="fp-hero-brand">CORPORATE SITE</div>
    <div class="fp-hero-logo">GrandFusion</div>
    <div class="fp-hero-logo-jp">株式会社 グランフュージョン</div>
    <h1 class="fp-hero-title">
      うまれかわる、<em>美しさ</em>を。<br>
      女性の人生を、輝かせるメーカーへ。
    </h1>
    <p class="fp-hero-sub">
      美容・教育・経営・ライフスタイルを融合させ、<br>
      女性が&quot;美しく、豊かに、自分らしく在る&quot;ための新しい価値を。<br>
      GrandFusionは、サロン様の成功をワンストップで支える総合メーカーです。
    </p>
    <div class="fp-hero-cta">
      <a href="https://grandfusion-official.site/lp/products/" class="btn btn-fill">事業を見る</a>
      <a href="https://liff.line.me/2004208943-gqypDjX5?unique_key=Tc2pkO&amp;ts=1784529110" target="_blank" rel="noopener" class="btn">お問い合わせ</a>
    </div>
  </div>
  <div class="fp-hero-scroll">SCROLL</div>
</section>

<!-- ===== VISION（メーカー・代表の想い） ===== -->
<section class="section fp-vision" id="vision">
  <div class="section-inner">
    <div class="section-head">
      <div class="section-en">Our Vision</div>
      <div class="section-jp">メーカー・代表の想い</div>
    </div>
    <div class="fp-vision-grid">
      <div class="fp-vision-text">
        <div class="fp-vision-catch">うまれかわる、美しさを。</div>
        <p>
          株式会社GrandFusionでは、<br>
          女性が<em>&quot;美しく、豊かに、自分らしく在る&quot;</em>ために、<br>
          美容・教育・経営・ライフスタイルを融合させた新しい価値を提供しています。
        </p>
        <p>
          サロン運営、マシン・商材開発、教育事業など、<br>
          美容を軸に多岐にわたるサービスを展開。<br>
          ただ商品を届けるのではなく、<em>&quot;女性の人生そのものを輝かせること&quot;</em>を使命に、<br>
          本質的な美しさと、持続可能な豊かさを追求しています。
        </p>
        <p>
          サロン様が結果を出し続けられるよう、教育スキーム・経営ノウハウ・実践サポートを構築。<br>
          「売るため」ではなく、<em>「愛され、選ばれ、続いていくサロン」</em>を育てるメーカーとして、<br>
          自信と可能性に満ち溢れた女性たちを全国へ輩出してまいります。
        </p>
        <div class="fp-vision-author">
          <span class="fp-vision-author-role">代表取締役</span>
          <span class="fp-vision-author-name">粕谷 ありさ</span>
          <span class="fp-vision-author-en">Arisa Kasuya / CEO, GrandFusion Co., Ltd.</span>
        </div>
      </div>
      <div class="fp-vision-image">
        <?php
        $ceo_img = $theme_uri . '/images/kasuya-arisa.jpg';
        if ( has_header_image() ) {
          $header_img = get_header_image();
        }
        ?>
        <img src="<?php echo esc_url( $ceo_img ); ?>" alt="株式会社GrandFusion 代表取締役 粕谷ありさ" loading="lazy">
      </div>
    </div>
  </div>
</section>

<!-- ===== PHILOSOPHY（3つの価値観） ===== -->
<section class="section fp-philosophy" id="philosophy">
  <div class="section-inner">
    <div class="section-head">
      <div class="section-en">Philosophy</div>
      <div class="section-jp">私たちの価値観</div>
    </div>
    <div class="fp-philos-grid">
      <article class="fp-philos-card">
        <div class="fp-philos-num">01</div>
        <div class="fp-philos-en">AUTHENTIC BEAUTY</div>
        <h3 class="fp-philos-title">本質的な美しさ</h3>
        <p>表面的ではない、その人の生き方そのものを輝かせる本質的な美しさを追求します。</p>
      </article>
      <article class="fp-philos-card">
        <div class="fp-philos-num">02</div>
        <div class="fp-philos-en">SUSTAINABLE GROWTH</div>
        <h3 class="fp-philos-title">持続可能な豊かさ</h3>
        <p>一過性ではなく、サロン様・お客様双方が長く豊かであり続けられる仕組みを設計します。</p>
      </article>
      <article class="fp-philos-card">
        <div class="fp-philos-num">03</div>
        <div class="fp-philos-en">EMPOWERED WOMEN</div>
        <h3 class="fp-philos-title">自分らしく在る女性へ</h3>
        <p>自信と可能性に満ち溢れた女性たちを、美容を起点に全国へ輩出してまいります。</p>
      </article>
    </div>
  </div>
</section>

<!-- ===== LINEUP CTA（事業領域への誘導） ===== -->
<section class="section fp-lineup" id="lineup">
  <div class="section-inner">
    <div class="section-head">
      <div class="section-en">Lineup</div>
      <div class="section-jp">事業・サービス</div>
    </div>
    <div class="fp-lineup-grid">
      <a href="<?php echo esc_url( home_url( '/beauty_salon_mgmt/' ) ); ?>" class="fp-lineup-card">
        <div class="fp-lineup-num">01</div>
        <h3>エステサロン経営</h3>
        <p>サロン開業から経営まで、ワンストップで支援。</p>
        <span class="fp-lineup-more">VIEW MORE →</span>
      </a>
      <a href="<?php echo esc_url( home_url( '/machine_sales/' ) ); ?>" class="fp-lineup-card">
        <div class="fp-lineup-num">02</div>
        <h3>エステマシン販売</h3>
        <p>医療発想で開発した自社クリニカルマシン。</p>
        <span class="fp-lineup-more">VIEW MORE →</span>
      </a>
      <a href="<?php echo esc_url( home_url( '/nuduque/' ) ); ?>" class="fp-lineup-card">
        <div class="fp-lineup-num">03</div>
        <h3>ヌドゥーク</h3>
        <p>看護師発想のプロ用化粧品ブランド。</p>
        <span class="fp-lineup-more">VIEW MORE →</span>
      </a>
      <?php /* アカデミー運営：非表示中（復活させたい時はこのコメントを外す）
      <a href="<?php echo esc_url( home_url( '/academy/' ) ); ?>" class="fp-lineup-card">
        <div class="fp-lineup-num">04</div>
        <h3>アカデミー運営</h3>
        <p>結果を出し続けるサロン経営者を育てる教育プログラム。</p>
        <span class="fp-lineup-more">VIEW MORE →</span>
      </a>
      */ ?>
      <?php /* ローマピンク：非表示中（復活させたい時はこのコメントを外す）
      <a href="<?php echo esc_url( home_url( '/romapink/' ) ); ?>" class="fp-lineup-card">
        <div class="fp-lineup-num">05</div>
        <h3>ローマピンク</h3>
        <p>サロン専売のスペシャルケアブランド。</p>
        <span class="fp-lineup-more">VIEW MORE →</span>
      </a>
      */ ?>
      <a href="https://hair-salon.grandfusion-official.site/" target="_blank" rel="noopener" class="fp-lineup-card">
        <div class="fp-lineup-num">04</div>
        <h3>美容室</h3>
        <p>自社直営の美容室運営。</p>
        <span class="fp-lineup-more">VIEW MORE →</span>
      </a>
    </div>
  </div>
</section>

<!-- ===== DIFFERENCE（他社メーカーとの違い） ===== -->
<section class="section fp-difference" id="difference">
  <div class="section-inner">
    <div class="section-head">
      <div class="section-en">Difference</div>
      <div class="section-jp">他社メーカーとの違い</div>
    </div>
    <div class="fp-diff-message">
      <div class="fp-diff-catch">流行ではなく、<em>本質</em>を届けるメーカー</div>
      <p>
        &quot;売れる&quot;より、&quot;必要か&quot;で選ぶ。<br>
        本当に良いと思えないものは扱いません。<br>
        私たちは「売れる商品」ではなく、<em>「残る美容」</em>を選びます。
      </p>
    </div>

    <div class="fp-essence-grid">
      <div class="fp-essence-card">
        <div class="fp-essence-num">01</div>
        <div class="fp-essence-cat">CURRENT</div>
        <div class="fp-essence-name">現場</div>
        <div class="fp-essence-detail">自社エステサロンを運営する、現役のプレイヤー視点。</div>
      </div>
      <div class="fp-essence-card">
        <div class="fp-essence-num">02</div>
        <div class="fp-essence-cat">MEDICAL</div>
        <div class="fp-essence-name">医療</div>
        <div class="fp-essence-detail">看護師視点と医療知識をベースにした、本物の安全性。</div>
      </div>
      <div class="fp-essence-card">
        <div class="fp-essence-num">03</div>
        <div class="fp-essence-cat">MANAGEMENT</div>
        <div class="fp-essence-name">経営</div>
        <div class="fp-essence-detail">売上導線・教育・融資・事業設計まで、経営を包括サポート。</div>
      </div>
      <div class="fp-essence-card">
        <div class="fp-essence-num">04</div>
        <div class="fp-essence-cat">INFRASTRUCTURE</div>
        <div class="fp-essence-name">インフラ</div>
        <div class="fp-essence-detail">不動産・内装・機械の常時サポートまで、運営の裏側を支える。</div>
      </div>
      <div class="fp-essence-card">
        <div class="fp-essence-num">05</div>
        <div class="fp-essence-cat">PHILOSOPHY</div>
        <div class="fp-essence-name">哲学</div>
        <div class="fp-essence-detail">流行ではなく、本当に必要なものだけを届ける姿勢。</div>
      </div>
    </div>

    <!-- ===== 比較表 ===== -->
    <div class="fp-compare-wrap">
      <table class="fp-compare-tbl">
        <thead>
          <tr>
            <th class="fp-compare-item">項目</th>
            <th class="fp-compare-other">一般的な美容メーカー</th>
            <th class="fp-compare-us">GrandFusion</th>
          </tr>
        </thead>
        <tbody>
          <tr><td>マシン</td><td>海外OEM・代理店販売が中心</td><td>医療知識をベースにオリジナル開発</td></tr>
          <tr><td>導入後サポート</td><td>操作説明のみ</td><td>売上導線・教育・経営まで支援</td></tr>
          <tr><td>実店舗運営</td><td>なし</td><td>自社エステサロン運営</td></tr>
          <tr><td>現場理解</td><td>営業主体</td><td>現場で結果を出し続ける運営主体</td></tr>
          <tr><td>教育体制</td><td>単発講習</td><td>売れる導線を網羅した教育体制</td></tr>
          <tr><td>コンサル</td><td>別料金・高額</td><td>伴走型コンサル選択可能</td></tr>
          <tr><td>融資支援</td><td>基本なし</td><td>融資通過率95%サポート</td></tr>
          <tr><td>開業支援</td><td>一部のみ</td><td>不動産・内装・事業設計の相談対応</td></tr>
        </tbody>
      </table>
    </div>
  </div>
</section>

<!-- ===== NEWS（最新ブログ・お知らせ） ===== -->
<?php
$latest_posts = new WP_Query( array(
  'post_type'      => 'post',
  'posts_per_page' => 3,
  'post_status'    => 'publish',
  'ignore_sticky_posts' => true,
) );
if ( $latest_posts->have_posts() ) :
?>
<section class="section fp-news" id="news">
  <div class="section-inner">
    <div class="section-head">
      <div class="section-en">News &amp; Blog</div>
      <div class="section-jp">お知らせ・ブログ</div>
    </div>
    <div class="fp-news-grid">
      <?php while ( $latest_posts->have_posts() ) : $latest_posts->the_post(); ?>
        <a href="<?php the_permalink(); ?>" class="fp-news-card">
          <div class="fp-news-img">
            <?php
            if ( has_post_thumbnail() ) {
              the_post_thumbnail( 'medium_large', array( 'loading' => 'lazy' ) );
            } else {
              echo '<span class="fp-news-no-img">GrandFusion</span>';
            }
            ?>
          </div>
          <div class="fp-news-body">
            <div class="fp-news-date"><?php echo esc_html( get_the_date( 'Y.m.d' ) ); ?></div>
            <h3 class="fp-news-title"><?php the_title(); ?></h3>
            <p class="fp-news-excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 50, '…' ) ); ?></p>
            <span class="fp-news-more">READ MORE →</span>
          </div>
        </a>
      <?php endwhile; ?>
    </div>
    <div class="fp-news-foot">
      <a href="<?php echo esc_url( home_url( '/blog/' ) ); ?>" class="btn">ブログ一覧を見る</a>
    </div>
  </div>
</section>
<?php
endif;
wp_reset_postdata();
?>

<!-- ===== MISSION（ダーク帯のメッセージ） ===== -->
<section class="section fp-mission">
  <div class="section-inner fp-mission-inner">
    <div class="fp-mission-en">Our Mission</div>
    <div class="fp-mission-jp">私たちの使命</div>
    <p class="fp-mission-quote">
      ただ商品を届けるのではなく、<br>
      <em>&quot;女性の人生そのものを輝かせること&quot;</em>を使命に。<br>
      本質的な美しさと、持続可能な豊かさを、<br>
      全国のサロン様とともに。
    </p>
  </div>
</section>

<!-- ===== CONTACT（CTAブロック） ===== -->
<section class="section fp-contact" id="contact">
  <div class="section-inner">
    <div class="section-head">
      <div class="section-en">Contact</div>
      <div class="section-jp">お問い合わせ</div>
    </div>
    <div class="fp-contact-card">
      <h3>製品導入・開業相談まで<br>お気軽にお問い合わせください</h3>
      <p>
        NUDUQUE製品の導入、業務用マシンのご紹介、サロン開業のご相談、<br>
        教育プログラムについてなど、お気軽にご相談ください。<br>
        専門の担当者がご対応いたします。
      </p>
      <div class="fp-contact-buttons">
        <a href="https://liff.line.me/2004208943-gqypDjX5?unique_key=Tc2pkO&amp;ts=1784529110" target="_blank" rel="noopener" class="btn btn-fill">お問い合わせフォーム</a>
        <a href="https://grandfusion-official.site/lp/products/" class="btn">サービス一覧を見る</a>
      </div>
    </div>
  </div>
</section>

<?php get_footer(); ?>
