<?php
/**
 * 404 エラーページ
 *
 * @package GrandFusion
 */
get_header();
?>

<section class="error-404 section">
  <div class="section-inner" style="text-align:center;max-width:720px;margin:0 auto;">
    <div class="error-num">404</div>
    <h1 class="error-title">お探しのページが見つかりませんでした</h1>
    <p class="error-text">
      アクセスしようとしたページは、削除されたか、URLが変更された可能性があります。<br>
      お手数ですが、トップページからアクセスし直してください。
    </p>
    <div class="error-buttons" style="display:flex;justify-content:center;gap:16px;flex-wrap:wrap;margin-top:40px;">
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn btn-fill">トップへ戻る</a>
      <a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="btn">お問い合わせ</a>
    </div>

    <div class="error-search" style="margin-top:60px;">
      <p style="font-size:13px;color:var(--c-text-light);margin-bottom:14px;">サイト内検索でお探しください</p>
      <?php get_search_form(); ?>
    </div>
  </div>
</section>

<?php
get_footer();
