<?php
/**
 * GrandFusion theme functions and definitions
 *
 * @package GrandFusion
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'GRANDFUSION_VERSION', '1.1.8' );

/**
 * アーカイブタイトルから「アーカイブ：」プレフィックスを除去
 */
add_filter( 'get_the_archive_title_prefix', '__return_empty_string' );

/**
 * /contact/ ページへのアクセスを エルメお問合せフォーム に301リダイレクト
 * 問い合わせを エルメフォーム（LIFF）に完全集約する
 */
add_action( 'template_redirect', function () {
	if ( is_page( 'contact' ) ) {
		wp_redirect( 'https://liff.line.me/2004208943-gqypDjX5?unique_key=Tc2pkO&ts=1784529110', 301 );
		exit;
	}
} );

/**
 * テーマセットアップ
 * テーマで使う基本機能（メニュー、アイキャッチ、タイトルタグ等）を登録
 */
function grandfusion_setup() {

	// 翻訳
	load_theme_textdomain( 'grandfusion', get_template_directory() . '/languages' );

	// <title>タグを自動出力
	add_theme_support( 'title-tag' );

	// アイキャッチ画像
	add_theme_support( 'post-thumbnails' );

	// HTML5マークアップ
	add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list',
		'gallery', 'caption', 'style', 'script',
	) );

	// カスタムロゴ
	add_theme_support( 'custom-logo', array(
		'height'      => 80,
		'width'       => 240,
		'flex-height' => true,
		'flex-width'  => true,
	) );

	// 自動feedリンク
	add_theme_support( 'automatic-feed-links' );

	// ブロックエディタのレスポンシブ埋め込み
	add_theme_support( 'responsive-embeds' );

	// エディタにテーマCSSを反映
	add_theme_support( 'editor-styles' );

	// ナビゲーションメニュー登録
	register_nav_menus( array(
		'primary' => esc_html__( 'メインメニュー（ヘッダー）', 'grandfusion' ),
		'footer'  => esc_html__( 'フッターメニュー', 'grandfusion' ),
	) );

	// 画像サイズ
	set_post_thumbnail_size( 1200, 800, true );
	add_image_size( 'gf-card', 800, 600, true );
	add_image_size( 'gf-hero', 1920, 1080, true );
}
add_action( 'after_setup_theme', 'grandfusion_setup' );


/**
 * CSS/JS の読み込み
 */
function grandfusion_enqueue_assets() {
	wp_enqueue_style(
		'grandfusion-style',
		get_stylesheet_uri(),
		array(),
		GRANDFUSION_VERSION
	);

	// 投稿ページでコメント返信用スクリプト
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'grandfusion_enqueue_assets' );


/**
 * ウィジェットエリア登録
 * フッターやサイドバーに、管理画面からウィジェットを追加できるようにする
 */
function grandfusion_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'サイドバー', 'grandfusion' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'ブログ記事ページのサイドバー', 'grandfusion' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => esc_html__( 'フッターウィジェット', 'grandfusion' ),
		'id'            => 'footer-1',
		'description'   => esc_html__( 'フッター内に表示されるウィジェット', 'grandfusion' ),
		'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="footer-widget-title">',
		'after_title'   => '</h4>',
	) );
}
add_action( 'widgets_init', 'grandfusion_widgets_init' );


/**
 * 抜粋の文字数を調整
 */
function grandfusion_excerpt_length( $length ) {
	return 80;
}
add_filter( 'excerpt_length', 'grandfusion_excerpt_length', 999 );


/**
 * 抜粋の末尾文字を変更
 */
function grandfusion_excerpt_more( $more ) {
	return '…';
}
add_filter( 'excerpt_more', 'grandfusion_excerpt_more' );


/**
 * 管理バーを最前面に
 */
function grandfusion_admin_bar_style() {
	if ( is_admin_bar_showing() ) {
		?>
		<style>
		.header{ top:32px !important; }
		@media(max-width:782px){ .header{ top:46px !important; } }
		</style>
		<?php
	}
}
add_action( 'wp_head', 'grandfusion_admin_bar_style' );


/**
 * カスタマイザー設定
 * 管理画面の「外観 → カスタマイズ」で変更可能な項目を追加
 */
function grandfusion_customize_register( $wp_customize ) {

	// セクション：会社情報
	$wp_customize->add_section( 'grandfusion_company', array(
		'title'    => __( '会社情報', 'grandfusion' ),
		'priority' => 30,
	) );

	// 設定：代表者写真
	$wp_customize->add_setting( 'grandfusion_ceo_image', array(
		'default'           => '',
		'sanitize_callback' => 'esc_url_raw',
	) );
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'grandfusion_ceo_image_control', array(
		'label'    => __( '代表者写真', 'grandfusion' ),
		'section'  => 'grandfusion_company',
		'settings' => 'grandfusion_ceo_image',
	) ) );

	// 設定：会社住所
	$wp_customize->add_setting( 'grandfusion_company_address', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	) );
	$wp_customize->add_control( 'grandfusion_company_address_control', array(
		'label'    => __( '会社住所', 'grandfusion' ),
		'type'     => 'text',
		'section'  => 'grandfusion_company',
		'settings' => 'grandfusion_company_address',
	) );

	// 設定：電話番号
	$wp_customize->add_setting( 'grandfusion_company_tel', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	) );
	$wp_customize->add_control( 'grandfusion_company_tel_control', array(
		'label'    => __( '電話番号', 'grandfusion' ),
		'type'     => 'text',
		'section'  => 'grandfusion_company',
		'settings' => 'grandfusion_company_tel',
	) );
}
add_action( 'customize_register', 'grandfusion_customize_register' );


/**
 * 検索フォームのテキスト
 */
function grandfusion_search_form_placeholder( $form ) {
	$form = str_replace( 'value="検索"', 'value="検索する"', $form );
	$form = str_replace( 'placeholder=""', 'placeholder="サイト内検索…"', $form );
	return $form;
}
add_filter( 'get_search_form', 'grandfusion_search_form_placeholder' );


/**
 * 検索結果から固定ページを除外しない（既定ではWP検索は両方を対象にする）
 * もし固定ページのみ・投稿のみに絞りたい場合はここで制御可能
 */


/**
 * Gutenberg（ブロックエディタ）にテーマカラーを追加
 */
function grandfusion_block_editor_colors() {
	add_theme_support( 'editor-color-palette', array(
		array( 'name' => __( 'ベース', 'grandfusion' ),       'slug' => 'base',       'color' => '#faf6f0' ),
		array( 'name' => __( 'ベージュ', 'grandfusion' ),     'slug' => 'beige',      'color' => '#ede3d3' ),
		array( 'name' => __( 'クリーム', 'grandfusion' ),     'slug' => 'cream',      'color' => '#f7f1e6' ),
		array( 'name' => __( 'ゴールド', 'grandfusion' ),     'slug' => 'gold',       'color' => '#b89968' ),
		array( 'name' => __( 'ダークゴールド', 'grandfusion' ),'slug' => 'gold-dark',  'color' => '#9c8062' ),
		array( 'name' => __( '本文文字色', 'grandfusion' ),    'slug' => 'text',       'color' => '#3d3329' ),
		array( 'name' => __( 'サブ文字色', 'grandfusion' ),    'slug' => 'text-sub',   'color' => '#6b5d4f' ),
	) );
}
add_action( 'after_setup_theme', 'grandfusion_block_editor_colors' );
