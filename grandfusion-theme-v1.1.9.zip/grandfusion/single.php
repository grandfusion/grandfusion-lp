<?php
/**
 * 個別投稿テンプレート（single.php）
 *
 * ブログ記事の個別ページに使用されます。
 *
 * @package GrandFusion
 */
get_header();
?>

<?php while ( have_posts() ) : the_post(); ?>

<section class="page-hero single-hero">
  <div class="page-hero-inner">
    <nav class="breadcrumb" aria-label="<?php esc_attr_e( 'パンくず', 'grandfusion' ); ?>">
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>">TOP</a>
      <span class="breadcrumb-sep">/</span>
      <a href="<?php echo esc_url( home_url( '/blog/' ) ); ?>">Blog</a>
      <span class="breadcrumb-sep">/</span>
      <span class="breadcrumb-current"><?php the_title(); ?></span>
    </nav>

    <div class="single-meta">
      <span class="single-date"><?php echo esc_html( get_the_date( 'Y.m.d' ) ); ?></span>
      <?php
      $categories = get_the_category();
      if ( ! empty( $categories ) ) {
        echo '<span class="single-cat">' . esc_html( $categories[0]->name ) . '</span>';
      }
      ?>
    </div>
    <h1 class="single-title"><?php the_title(); ?></h1>
  </div>
</section>

<section class="single-body section">
  <article id="post-<?php the_ID(); ?>" <?php post_class( 'single-article' ); ?>>
    <?php if ( has_post_thumbnail() ) : ?>
      <div class="single-thumb">
        <?php the_post_thumbnail( 'large', array( 'loading' => 'eager' ) ); ?>
      </div>
    <?php endif; ?>

    <div class="entry-content single-content">
      <?php the_content(); ?>

      <?php
      wp_link_pages( array(
        'before' => '<div class="page-links">' . esc_html__( 'ページ:', 'grandfusion' ),
        'after'  => '</div>',
      ) );
      ?>
    </div>

    <?php
    $tags = get_the_tags();
    if ( $tags ) :
    ?>
    <div class="single-tags">
      <?php foreach ( $tags as $tag ) : ?>
        <a href="<?php echo esc_url( get_tag_link( $tag->term_id ) ); ?>" class="single-tag">#<?php echo esc_html( $tag->name ); ?></a>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <nav class="single-pager">
      <div class="single-pager-prev">
        <?php previous_post_link( '%link', '<span class="single-pager-label">← 前の記事</span><span class="single-pager-title">%title</span>' ); ?>
      </div>
      <div class="single-pager-next">
        <?php next_post_link( '%link', '<span class="single-pager-label">次の記事 →</span><span class="single-pager-title">%title</span>' ); ?>
      </div>
    </nav>

    <?php
    if ( comments_open() || get_comments_number() ) {
      comments_template();
    }
    ?>
  </article>
</section>

<?php endwhile; ?>

<!-- 関連記事 -->
<?php
$related = new WP_Query( array(
  'post_type'      => 'post',
  'posts_per_page' => 3,
  'post__not_in'   => array( get_the_ID() ),
  'orderby'        => 'rand',
) );
if ( $related->have_posts() ) :
?>
<section class="single-related section">
  <div class="section-inner">
    <div class="section-head">
      <div class="section-en">Related</div>
      <div class="section-jp">関連記事</div>
    </div>
    <div class="archive-grid">
      <?php while ( $related->have_posts() ) : $related->the_post(); ?>
        <a href="<?php the_permalink(); ?>" class="archive-card">
          <div class="archive-card-img">
            <?php
            if ( has_post_thumbnail() ) {
              the_post_thumbnail( 'medium_large', array( 'loading' => 'lazy' ) );
            } else {
              echo '<span class="archive-card-no-img">GrandFusion</span>';
            }
            ?>
          </div>
          <div class="archive-card-body">
            <div class="archive-card-date"><?php echo esc_html( get_the_date( 'Y.m.d' ) ); ?></div>
            <h3 class="archive-card-title"><?php the_title(); ?></h3>
          </div>
        </a>
      <?php endwhile; ?>
    </div>
  </div>
</section>
<?php
endif;
wp_reset_postdata();
?>

<?php
get_footer();
