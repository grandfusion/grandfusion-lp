<?php
/**
 * Footer template for the GrandFusion theme.
 *
 * @package GrandFusion
 */
?>

</main><!-- #content -->

<footer class="footer" role="contentinfo">
  <div class="footer-inner">

    <div class="footer-brand">
      <div class="footer-logo">GrandFusion</div>
      <div class="footer-tag">株式会社グランフュージョン</div>
    </div>

    <nav class="footer-nav" aria-label="<?php esc_attr_e( 'フッターナビゲーション', 'grandfusion' ); ?>">
      <?php
      if ( has_nav_menu( 'footer' ) ) {
        wp_nav_menu( array(
          'theme_location' => 'footer',
          'container'      => false,
          'menu_class'     => 'footer-nav-list',
          'items_wrap'     => '%3$s',
          'depth'          => 1,
          'fallback_cb'    => false,
        ) );
      } else {
        ?>
        <a href="<?php echo esc_url( home_url( '/about/' ) ); ?>">会社概要</a>
        <a href="<?php echo esc_url( home_url( '/beauty_salon_mgmt/' ) ); ?>">エステサロン経営</a>
        <a href="<?php echo esc_url( home_url( '/machine_sales/' ) ); ?>">マシン販売</a>
        <a href="<?php echo esc_url( home_url( '/nuduque/' ) ); ?>">ヌドゥーク</a>
        <a href="https://hair-salon.grandfusion-official.site/" target="_blank" rel="noopener">美容室</a>
        <a href="<?php echo esc_url( home_url( '/blog/' ) ); ?>">BLOG</a>
        <a href="<?php echo esc_url( home_url( '/recruit/' ) ); ?>">採用情報</a>
        <a href="<?php echo esc_url( home_url( '/faq/' ) ); ?>">よくある質問</a>
        <a href="https://liff.line.me/2004208943-gqypDjX5?unique_key=Tc2pkO&amp;ts=1784529110" target="_blank" rel="noopener">お問い合わせ</a>
        <a href="<?php echo esc_url( home_url( '/policy/' ) ); ?>">プライバシーポリシー</a>
        <?php
      }
      ?>
    </nav>

    <div class="footer-meta">
      <div class="copyright">© <?php echo esc_html( date_i18n( 'Y' ) ); ?> GrandFusion Co., Ltd. All Rights Reserved.</div>
    </div>

  </div>
</footer>

<?php wp_footer(); ?>

<script>
(function(){
  var btn = document.getElementById('menuBtn');
  var nav = document.getElementById('primary-nav');
  if (btn && nav) {
    btn.addEventListener('click', function(){
      var open = nav.classList.toggle('is-open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
      btn.classList.toggle('is-active', open);
    });
    // 子メニュー以外のリンクは閉じる
    nav.querySelectorAll('a').forEach(function(a){
      a.addEventListener('click', function(){
        var li = a.closest('.menu-item-has-children');
        if (li && a === li.querySelector(':scope > a')) return;
        if (a.closest('.sub-menu')) return;
        nav.classList.remove('is-open');
        btn.classList.remove('is-active');
        btn.setAttribute('aria-expanded', 'false');
      });
    });
  }

  /* ▼ ヌドゥーク項目にサブメニューが無ければ「NUDUQUEトップページ」を注入 */
  document.querySelectorAll('.nav-list > li.menu-item').forEach(function(li){
    var a = li.querySelector(':scope > a');
    if (!a) return;
    var txt = (a.textContent || '').trim();
    if (txt.indexOf('ヌドゥーク') === -1 && txt.indexOf('NUDUQUE') === -1) return;
    if (li.querySelector(':scope > .sub-menu')) return; // 既に子メニューあり
    li.classList.add('menu-item-has-children');
    var sub = document.createElement('ul');
    sub.className = 'sub-menu';
    sub.innerHTML = '<li class="menu-item"><a href="https://lp.grandfusion-official.site/" target="_blank" rel="noopener"><strong>NUDUQUE トップページ</strong><small>brand top</small></a></li>';
    li.appendChild(sub);
  });

  /* ▼ ドロップダウン：PC・モバイルとも「クリックで開閉」方式に統一 */
  document.querySelectorAll('.nav-list .menu-item-has-children > a').forEach(function(a){
    a.addEventListener('click', function(e){
      var li = a.parentElement;
      var sub = li.querySelector(':scope > .sub-menu');
      if (!sub) return;
      e.preventDefault();
      var wasOpen = li.classList.contains('is-open');
      // 他の開いてる項目を閉じる（同時に1つだけ開く）
      document.querySelectorAll('.nav-list .menu-item-has-children.is-open').forEach(function(other){
        if (other !== li) other.classList.remove('is-open');
      });
      li.classList.toggle('is-open', !wasOpen);
    });
  });

  /* ▼ 外側クリックでプルダウンを閉じる */
  document.addEventListener('click', function(e){
    if (!e.target.closest('.nav-list .menu-item-has-children')) {
      document.querySelectorAll('.nav-list .menu-item-has-children.is-open').forEach(function(li){
        li.classList.remove('is-open');
      });
    }
  });

  /* ▼ Escキーで閉じる */
  document.addEventListener('keydown', function(e){
    if (e.key === 'Escape') {
      document.querySelectorAll('.nav-list .menu-item-has-children.is-open').forEach(function(li){
        li.classList.remove('is-open');
      });
    }
  });
})();
</script>

</body>
</html>
