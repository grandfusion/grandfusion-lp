<?php
/**
 * メインテンプレート（最終フォールバック）
 *
 * @package GrandFusion
 */
get_header();
?>

<section class="page-hero">
  <div class="page-hero-inner">
    <div class="page-en">Blog</div>
    <h1 class="page-title"><?php bloginfo( 'name' ); ?></h1>
  </div>
</section>

<section class="archive-body section">
  <div class="section-inner">
    <?php if ( have_posts() ) : ?>
      <div class="archive-grid">
        <?php while ( have_posts() ) : the_post(); ?>
          <a href="<?php the_permalink(); ?>" class="archive-card">
            <div class="archive-card-img">
              <?php
              if ( has_post_thumbnail() ) {
                the_post_thumbnail( 'medium_large', array( 'loading' => 'lazy' ) );
              } else {
                echo '<span class="archive-card-no-img">GrandFusion</span>';
              }
              ?>
            </div>
            <div class="archive-card-body">
              <div class="archive-card-meta">
                <span class="archive-card-date"><?php echo esc_html( get_the_date( 'Y.m.d' ) ); ?></span>
              </div>
              <h2 class="archive-card-title"><?php the_title(); ?></h2>
              <p class="archive-card-excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 50, '…' ) ); ?></p>
              <span class="archive-card-more">READ MORE →</span>
            </div>
          </a>
        <?php endwhile; ?>
      </div>

      <div class="archive-pagination">
        <?php the_posts_pagination(); ?>
      </div>
    <?php else : ?>
      <div class="archive-empty">
        <p>該当する記事が見つかりませんでした。</p>
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn">トップへ戻る</a>
      </div>
    <?php endif; ?>
  </div>
</section>

<?php
get_footer();
